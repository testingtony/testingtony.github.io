import os
from html import unescape
from typing import List

import frontmatter
import marko


class Jobs:
    def __init__(self, folder):
        self.folder = folder
        self.jobs = None

    def load_jobs(self):
        files = [f for f in os.listdir(self.folder) if f.endswith(".md")]
        files.sort()
        files = files[::-1]
        self.jobs = [frontmatter.load(os.path.join(self.folder, f)) for f in files]

    def get_jobs(self, type) -> List[frontmatter.Post]:
        return [s for s in self.jobs if s["type"] == type]

    @classmethod
    def get_paragraphs(cls, job):
        content = marko.parse(job.content)
        rtl = [
            " ".join([t.children for t in para if t.get_type() == "RawText"])
            for para in [
                p.children for p in content.children if p.get_type() == "Paragraph"
            ]
        ]
        rtl = [unescape(p) for p in rtl]
        return rtl
