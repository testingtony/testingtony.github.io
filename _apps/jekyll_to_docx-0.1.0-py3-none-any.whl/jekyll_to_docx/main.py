import argparse

from jekyll_to_docx.cv import CV
from jekyll_to_docx.jobs import Jobs


def main(folder: str, output_name: str):
    jobs = Jobs(folder)
    jobs.load_jobs()

    cv = CV(output_name)
    cv.load_template()

    cv.load_jobs(jobs)

    cv.save()


def cli():
    parser = argparse.ArgumentParser("jekyll_to_docx")

    parser.add_argument(
        "destination_file",
        help="The name of the file to save to",
        nargs="?",
        default="cv.docx",
    )
    parser.add_argument(
        "-j",
        "--jobs-folder",
        help="The name of the folder with the jobs .md files in",
        default="_testjobs",
    )

    args = parser.parse_args()
    main(args.jobs_folder, args.destination_file)


if __name__ == "__main__":
    main("_testjobs", "cv.docx")
