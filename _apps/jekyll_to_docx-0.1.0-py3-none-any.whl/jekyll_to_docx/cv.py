import importlib.resources as importres
import jekyll_to_docx

from jekyll_to_docx.jobs import Jobs

from docx import Document
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_BREAK

from html import unescape


class CV:
    def __init__(self, filename=None, template="template.docx"):
        self.filename = filename
        self.document = None
        self.template = template

    def load_template(self):
        iif = importres.files(jekyll_to_docx) / self.template
        with importres.as_file(iif) as f:
            document = Document(f)
            self.document = document

    def load_jobs(self, jobs: Jobs):
        document = self.document

        paragraph = document.add_paragraph(
            "9191 233 0870 / ku.oc.dyorlohynot@nideknil"[::-1], style="Summary"
        )
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

        summary = jobs.get_jobs("summary")[0]
        self.add_summary(summary)

        roles = jobs.get_jobs("permanent")
        self.add_jobs("Employment", roles)

        roles = jobs.get_jobs("contract")
        self.add_jobs("Contracts", roles)

        for title, details in summary["education"].items():
            self.add_education(title, details)

    def add_summary(self, summary):

        document = self.document
        document.add_heading("Summary", level=2)
        for p in Jobs.get_paragraphs(summary):
            document.add_paragraph(unescape(p), style="Summary")

        self.add_key_skills(summary)

    def add_jobs(self, title, jobs):
        document = self.document
        document.add_heading(title, level=2)
        for job in jobs:
            whens = job["when"]
            if isinstance(whens, str):
                whens = [
                    whens,
                ]
            for when in whens:
                h = document.add_heading("\t", level=3)
                h.add_run(unescape(when))
                h.add_run("\t")
                h.add_run(unescape(job["role"])).bold = True
                try:
                    h.add_run(", " + unescape(job["team"]))
                except KeyError:
                    pass
                h.add_run(" — ")
                h.add_run(unescape(job["who"]))
                h.add_run(".")

            try:
                for skill in job["skills"]:
                    document.add_paragraph(skill, style="Employment Skill")
            except KeyError:
                pass

            if job["who"] == "Tony Holroyd Limited":
                document.add_paragraph("")
            else:
                for para in Jobs.get_paragraphs(job):
                    document.add_paragraph(unescape(para))

    def add_education(self, title, details):
        document = self.document
        document.add_heading(title, level=2)
        for detail in details:
            bits = detail.split(" ", 1)
            detail = f"\t{bits[0]}\t{bits[1]}"
            document.add_heading(detail, level=3)

    def add_key_skills(self, job):
        document = self.document
        document.add_heading("Key Skills", level=2)
        section = document.add_section(WD_SECTION.CONTINUOUS)

        sectPr = section._sectPr
        cols = sectPr.xpath("./w:cols")[0]
        cols.set(qn("w:num"), "3")

        first = True
        for heading, skills in job["skills"].items():
            r = document.add_paragraph("", style="Experience Role").add_run()
            if not first:
                r.add_break(WD_BREAK.COLUMN)
            first = False
            r.add_text(heading)
            for k, v in skills.items():
                document.add_paragraph(f"{k}\t{v}", style="Experience Skill")
        section = document.add_section(WD_SECTION.CONTINUOUS)

        sectPr = section._sectPr
        cols = sectPr.xpath("./w:cols")[0]
        cols.set(qn("w:num"), "1")

    def save(self):
        self.document.save(self.filename)
